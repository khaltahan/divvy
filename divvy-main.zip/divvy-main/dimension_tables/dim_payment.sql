CREATE EXTERNAL TABLE [dbo].[dim_payment] WITH(
    LOCATION = 'star/dim_payment',
    DATA_SOURCE = [azure_dfs_core_windows_net],
    FILE_FORMAT = [SynapseDelimitedTextFormat]
) AS (
    SELECT 
        payment_id,
        date,
        amount,
        rider_id
    FROM staging_payment
);
